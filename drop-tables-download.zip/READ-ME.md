# Current server drop-table reference

Snapshot: **4 October 2026**, copied lab server used for current play.
Extracted from compiled server content. Definitions do not guarantee current availability or exact per-kill rates.

## Files to use

Open **index.html** in a browser for an offline searchable reference.
It needs no login, Internet connection or external scripts. Search by item name,
creature name or internal class code. The first 300 matches are displayed; narrow
large searches. Full exports are in the accompanying ZIP:

| File | Contents |
|---|---|
| `npcs.csv` | All 651 loaded NPC templates: level/range, behavior, numbered treasure table and zone references |
| `npc_item_chances.csv` | 98,121 NPC–item inventory-generation relationships with nominal probabilities |
| `item_sources.csv` | Same relationships sorted by item name for reverse lookup |
| `container_slots.csv` | 2,585 inherited object/worn/gold/crystal slots, including containers and non-NPC objects |
| `pool_slots.csv` | 6,294 effective slots in 220 loaded random pools; duplicates are intentional weight |
| `pool_outcomes.csv` | 16,925 flattened pool outcomes with nominal conditional probabilities and money ranges |
| `value_tables.csv` | All 1,891 file entries in `treasure.000` through `.009` |
| `value_table_users.csv` | NPC templates that use each numbered value table |
| `items.csv` | All 5,952 loaded object definitions: names, codes, base values, levels, raw effects, requirements, actions and provenance |
| `zone_spawns.csv` | 2,173 population/group/ambush references from listed zones |
| `zones.csv` | All 130 listed zone definitions and their loot-related flags |
| `world_placements.csv` | 6,881 relevant NPC/container/pool placements from worlds referenced by listed zones, with per-instance overrides |
| `world_directives.csv` | Separate procedural world `treasure`/`monster` directives; none occur in these listed world files |
| `quest_rewards.csv` | All 451 loaded quest records, including rewards and requirement rows; not a monster-drop table |
| `special_rules.csv` | Scripted reward mechanisms and activation caveats |
| `content_actions.csv` | Object-defined actions that create objects or invoke special reward mechanisms |
| `issues.csv` | 42 entries discarded by the native 128-entry random-pool cap |

The CSVs open in spreadsheet applications. Item names are not unique: **use class
codes** to distinguish different versions with the same displayed name. Empty zone
references mean no direct listed-zone/world placement was found, not that the
object is impossible to create through a script, summon, quest or GM command.

## There is not one universal drop table

### 1. Inventory slots and shared random pools

A creature inherits its parent's container contents and adds its own declarations.
An empty child container or treasure block does **not** erase the inherited list.
Each `object` slot is generated separately; repeated slots can create multiple
items. `worn` slots are equipment, not ordinary loot.

The outer object's `random` property gates generation:

- `random 1` means a nominal 1% attempt.
- `random 25` means a nominal 25% attempt.
- **`random 0` means no chance check: unconditional**, not zero probability.
- Values above 100 always pass the check; negative nonzero values never pass.

A random pool chooses one of its effective entries uniformly by slot. Repeating
an item increases its weight. Nested pool selection recurses, **without applying
that nested pool's own `random` property again**. MoneyBag/ManaBag ranges specify
amounts, not weights. The outer admission gate is applied only where the caller
actually checks it; some script callers call `makeObj()` directly.

The engine retains only the first **128** entries of each pool. In this snapshot,
`RandomRareGlowDye` declares 170 entries but only the first 128 are effective.
The 42 ignored entries are listed in `issues.csv`; they are not advertised as
possible results of that table. A discarded entry may still have another source.

The flattened NPC percentage combines independent inventory slots as
`1 − product(1 − per-slot probability)`. Expected count is also exported. These
are nominal RNG probabilities; the legacy `rand() % range` implementation has
small modulo bias. They are not empirically measured drop rates.

### 2. Numbered level/value tables

A nonnegative `treasure` property invokes `WorldObject::generateTreasure()` when
an NPC is created, **in addition to its normal inventory slots**.

For effective level `L = max(actual NPC level, 2)`:

1. Draw an integer value from `15L` through `40L`, inclusive.
2. Independently, a nominal 1% roll doubles that value.
3. A nominal `1/11` branch changes the NPC's currency balance: one-third of that
   branch adds mana, two-thirds gold. It does not create an inventory item.
4. Otherwise the engine searches the numbered item table by value and chooses
   an entry from its candidate range, then attempts to add that object.

**Do not divide by the number of rows in a numbered table.** These are not uniform
loot pools. The loader orders entries using `netWorth(50)`, while selection compares
an item's raw `value`. Its candidate endpoints are inclusive, and the endpoint can
include the first value above the target or the null terminator. Its insertion
loop can also append an extra occurrence when insertion happens before the tail.
The export preserves file order and membership rather than claiming a sanitized
sort or fabricated exact per-item percentages. Precise rates for this mechanism
would require a separately validated reproduction of those native edge cases.

**Important current-build behavior:** the death handler's code for dropping the
NPC's wallet gold/mana is commented out. Thus the currency branch above is **not
a guaranteed gold/mana bag on death**. Explicit bags generated into an inventory
are a separate mechanism. This distinction helps explain XP-producing fights
that produce no saleable loot or cash.

| Numbered table | File entries |
|---|---:|
| 000 | 31 |
| 001 | 168 |
| 002 | 309 |
| 003 | 180 |
| 004 | 272 |
| 005 | 180 |
| 006 | 94 |
| 007 | 164 |
| 008 | 181 |
| 009 | 312 |

`value_table_users.csv` connects these pools to creatures. Membership is only a
candidate source: a creature's actual level/value range may never select a given
entry. The HTML reverse lookup shows this separately from inventory probabilities.

### 3. What actually falls on death

Generation and lootability are different. The NPC death path normally drops
eligible carried items, but excludes heads, staff-tagged objects, home decorations,
and equipped/wielded gear. Summoned NPCs and tournament/no-treasure contexts do not
use ordinary death drops. Worn containers have additional restrictions.

The direct NPC inventory export excludes worn/head/staff/home-decoration entries.
There are no nested populated-container endpoints in this snapshot's NPC inventory
routes. The full container export remains available for other chests/objects.
A named `Summoned...` template appearing in the reference does **not** mean a
player-summoned instance will drop it. Instance context still controls.

Three listed zones explicitly set `noTreasureDrop`:
`D_DUACH_01.ZON`, `D_ENID_ROSE_01.ZON`, and `D_JUDGMENT_01.ZON`.
Other combat flags and runtime context can also restrict drops.

NPCs can pick up existing world items; some can acquire money through theft.
Those dynamic holdings are not fully predicted by their original template.
Battlefield cleanup can destroy unclaimed treasure. Capacity, eligibility,
ownership and successful pickup still matter after an item is generated.

## The rings we discussed

**Basic Ratling → `RandomMonsterRing` → `MysticismWardRingI`:**

- Outer ring gate: **1%**.
- Effective ring pool: **20 slots**, 16 distinct ring codes.
- +15% Mysticism ring: one slot, or **5% conditional on the ring pool firing**.
- Combined inventory-generation chance: **0.05%, approximately 1 in 2,000**
  ordinary eligible Ratling instances, before access/pickup considerations.
- Requires level **40**, provides **+15% Mysticism resistance** and
  **−15% Elementalism resistance**. The ring's required level is not compared
  with the Ratling's level by this pool.
- Copper Ring occupies five slots: **0.25%** via the Ratling ring roll.

The **+25% Mysticism ring** also exists: `MysticismWardRingII`, level **70**,
with **−25% Elementalism resistance**. It is absent from the basic Ratling ring
pool. It appears in other pools such as `RandomRareMagicHelm`, `MistTreasureII`,
`MidPointTreasureChest`, `Sewerdrop3`, `GodHelmTable`, `NGWeps`, and others.
Search its exact code in the reference to see all extracted routes. A pool's
name is not a reliable item-category restriction.

## Chests, quests and special mechanisms

- World-placed objects can override their parent template's contents, properties
  and actions. See `world_placements.csv`; room IDs are templates, not navigation
  directions or proof that an instance is currently available.
- All loaded quest reward/requirement records are included separately. A quest
  reward is conditional on that quest, not a drop rate or proof its giver is live.
- The gem chest uses `GemGameTreasure0`–`8`, which are all included as pools.
  Its reward choice depends on talisman classification and offered gold; see
  `special_rules.csv`. The current source disables the old random destroy/teleport
  branches (`chance < 0`), so the nearby “25% chance” comment is not the current
  success probability. Other validity checks and damaging penalties still apply.
- Pumpkin spawning is a room/NPC behavior, not a kill reward. The current source
  chooses ShockJackolantern on `rand100() > 98`, otherwise LargePumpkin; spawn
  attempts also depend on the room population and existing pumpkins.
- Mine reward pools exist, but the `mines-dropper` dispatcher branches are
  commented out. Existence of a pool does not establish an active automatic source.
- Easter-egg generation is present in the compiled `mlfaery.cpp` source but has
  no active caller there; older `faery.cpp` is not in this build's CMake source list.
  It is marked dormant/unverified, not advertised as a currently farmable drop.
- Crafting, shop stock and GM-created items are not monster drops. Their presence
  among object definitions does not by itself make them naturally obtainable.
